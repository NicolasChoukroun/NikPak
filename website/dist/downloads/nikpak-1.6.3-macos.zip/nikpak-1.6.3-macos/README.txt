NikPak 1.6.3 for macOS - NikPak (archiver) and unNik (free archive browser)

Install:    ./install.sh
Uninstall:  ./install.sh --uninstall

Or run the programs from this folder: ./nikpak (window) - ./nikpak -help (command line) - ./unNik
User guide: https://nikpak.nikkoid.com
NikPak is shareware: free for personal use, companies need one licence per seat.
(c) 2026 Nicolas Choukroun, distributed by Nikkoid LLC.
