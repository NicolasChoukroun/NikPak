#!/bin/sh
# install.sh - install NikPak and unNik for this user, with the right-click menu.
#   ./install.sh               install (Linux: ~/.local/bin, macOS: /usr/local/bin)
#   PREFIX=/opt/bin ./install.sh   install somewhere else
#   ./install.sh --uninstall   remove the programs and the menu
set -e
cd "$(dirname "$0")"
if [ "$(uname -s)" = "Darwin" ]; then BIN="${PREFIX:-/usr/local/bin}"; else BIN="${PREFIX:-$HOME/.local/bin}"; fi
SUDO=""
mkdir -p "$BIN" 2>/dev/null || SUDO=sudo
[ -w "$BIN" ] || SUDO=sudo
if [ "$1" = "--uninstall" ]; then
  "$BIN/nikpak" --uninstall-menu 2>/dev/null || true
  $SUDO rm -f "$BIN/nikpak" "$BIN/unNik"
  echo "NikPak was removed from $BIN."
  exit 0
fi
$SUDO mkdir -p "$BIN"
$SUDO cp nikpak unNik "$BIN/"
$SUDO chmod 755 "$BIN/nikpak" "$BIN/unNik"
# downloaded programs are quarantined by macOS: allow these two
[ "$(uname -s)" = "Darwin" ] && $SUDO xattr -d com.apple.quarantine "$BIN/nikpak" "$BIN/unNik" 2>/dev/null || true
"$BIN/nikpak" --install-menu || echo "(The right-click menu could not be added; NikPak works without it.)"

# Put the folder on the PATH, so `nikpak` and `unNik` open from any shell.
# /usr/local/bin (macOS) is already in the default PATH, so nothing is needed.
case ":$PATH:" in
  *":$BIN:"*) ;;
  *)
    LINE="export PATH=\"$BIN:\$PATH\""
    case "${SHELL##*/}" in
      zsh)  RC="$HOME/.zshrc" ;;
      bash) RC="$HOME/.bashrc" ;;
      *)    RC="$HOME/.profile" ;;
    esac
    [ -f "$RC" ] || RC="$HOME/.profile"
    if grep -Fqx "$LINE" "$RC" 2>/dev/null; then
      :
    else
      printf '\n# added by NikPak so that `nikpak` opens in any shell\n%s\n' "$LINE" >> "$RC"
      echo "Added $BIN to the PATH in $RC (open a new terminal to use it)."
    fi
    PATH="$BIN:$PATH"
    ;;
esac

echo
VER=$("$BIN/nikpak" -V 2>/dev/null | head -1 | cut -d' ' -f2)
echo "NikPak $VER is installed in $BIN."
echo "  nikpak          opens the NikPak window (drop files to compress)"
echo "  unNik           opens the archive browser"
echo "  nikpak -help    command line"
echo "  nikpak -V       version"
case ":$PATH:" in
  *":$BIN:"*) ;;
  *) echo; echo "Note: start a new terminal, or run:  $LINE" ;;
esac
